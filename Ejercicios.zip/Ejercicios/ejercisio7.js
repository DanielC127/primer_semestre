var genero = prompt("Ingresa tu género: masculino/femenino").toLowerCase();
var edad = parseInt(prompt("Ingresa tu edad"));
var ayuda;


if (genero === "masculino") {
    ayuda = 40000;
    alert("El valor de tu ayuda mensual es $" + ayuda);
} else if (genero === "femenino") {
    if (edad > 50) {
        ayuda = 120000; 
    } else if (edad >= 30 && edad <= 50) {
        ayuda = 100000; 
    } else {
        ayuda = 0;
    }
    
    if (ayuda > 0) {
        alert("El valor de tu ayuda mensual es $" + ayuda);
    } else {
        alert("No recibes ayuda mensual.");
    }
} else {
    alert("Género no válido. Por favor ingresa 'masculino' o 'femenino'.");
}
