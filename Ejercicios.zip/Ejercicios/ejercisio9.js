var angulo1 = parseInt(prompt("Ingresa el angulo uno"));
var angulo2 = parseInt(prompt("Ingresa el angulo dos"));
var angulo3 = parseInt(prompt("Ingresa el angulo tres"));
var verificacion = (angulo1 + angulo2 + angulo3);

if (verificacion === 180 ) {
    alert ("Tu triangulo si es valido")
} else (verificacion != 180 ) 
{ 
    alert ("Tu triangulo es invalido") 
}
    