let modelo = prompt("ingrese el modelo de su auto")

switch(modelo){
    case "119": document.write("el auto esta defectuoso, llevar a garantía")
        break
    case "179": document.write("el auto esta defectuoso, llevar a garantía")
        break
    case "189": document.write("el auto esta defectuoso, llevar a garantía")
        break
    case "195": document.write("el auto esta defectuoso, llevar a garantía")
        break
    case "221": document.write("el auto esta defectuoso, llevar a garantía")
        break
    case "780": document.write("el auto esta defectuoso, llevar a garantía")
    default: document.write("Su auto no esta defectuoso")
}