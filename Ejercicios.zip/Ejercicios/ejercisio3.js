var tipoLavadora = prompt("Usaste la lavadora tipo 1 o 2");
var cantidad = parseInt(prompt("¿Cuántas lavadoras usarás?"));
var horas = parseInt(prompt("¿Cuántas horas las usaste?"));

var costoPorLavadora;
if (tipoLavadora === "1") {
    costoPorLavadora = 4000;
} else if (tipoLavadora === "2") {
    costoPorLavadora = 3000;
} else {
    alert("Tipo de lavadora no válido.");
}

// Calcular costo total
if (costoPorLavadora) {
    costoTotal = cantidad * horas * costoPorLavadora;

    
    if (cantidad > 3) {
        costoTotal *= 0.97; 
    }

    alert("Costo total por alquilar " + cantidad + " lavadoras tipo " + tipoLavadora + " por " + horas + " horas: " + costoTotal);
}




